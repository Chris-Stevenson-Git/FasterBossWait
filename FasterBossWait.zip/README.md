# Faster Boss Wait

This is a mod for Risk of Rain 2 which helps to speed up the downtime between killing a boss and being able to leave the zone. 

Once the boss has been dispatched, each kill will increase the charge of the teleporter by 1% (can be changed in the config file).

## Installation (Mod Manager)
 1. Click the install with Mod Manager button
 2. Done
  
## Installation (Manual)
 1. Extract "FasterBossWait.dll" from the zip file and place it into  "/Risk of Rain 2/BepInEx/plugins/" folder.
 2. Done

Note: The mod must be enabled and run at least once before a config file will be generated.